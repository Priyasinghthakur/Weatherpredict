export const geoApioptions = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': 'ce222f844dmshe102f93562134c4p184e64jsn78b106510366',
		'X-RapidAPI-Host': 'wft-geo-db.p.rapidapi.com'
	}
};

export const GEO_API_URL="https://wft-geo-db.p.rapidapi.com/v1/geo"

export const WEATHER_API="https://api.openweathermap.org/data/2.5";

export const WEATHER_KEY="4b09d4ce9ee52e6acc69dce4c7051dd5"

export const FORCAST_API="https://pro.openweathermap.org/data/2.5"